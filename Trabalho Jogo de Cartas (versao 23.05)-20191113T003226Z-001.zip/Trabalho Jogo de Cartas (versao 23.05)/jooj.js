function RNG() { //random number generator TABAJARA meu parceiro
    let rng = parseInt(Math.random() * (4 - 0) + 0);
    return rng;
}

function TirarCarta(rng) {
    let array = [2, 3, 5, 7];
    return array[rng];
}

function ExecutarCarta(rng, jogAnterior, jogAtual) {
    switch (rng) {
        case 2: JogCarta.carta2(jogAtual);
            
            break;
        case 3: JogCarta.carta3(jogAnterior, jogAtual);
        
            break;
        case 5: JogCarta.carta5(jogAtual);
        
            break;
        case 7: JogCarta.carta7(jogAnterior, jogAtual);

            break;
    }
}

function Rodada() {
    let ptAux = JogCarta.ptJogadores;
    let ptAux2 = ptAux;
    let qtd = 1;

    while (ptAux2)
}