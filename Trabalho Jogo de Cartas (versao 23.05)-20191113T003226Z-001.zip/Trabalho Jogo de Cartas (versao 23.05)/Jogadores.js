class Jogadores { //classe que serve como Nó que contém o nome e um ponteiro pro proximo elemento, proxJogador
    constructor(nome) {
        this.nome = nome;
        this.proxJogador = null;
    }
}