class JogoEnc {
    constructor() {
        this.qtd = 0;
        this.ptJogadores = null;
        this.nomeJogadores = [];
    }

    Vazio() { //Método para verificar se a lista está vazia
        if (this.ptJogadores == null)
            return true;
        else
            return false; 
    }

    Busca (nome, funcao) { //Método para executar uma busca pelos elementos
        if (this.Vazio())
            return -1;
        else {
            let ptAux = this.ptJogadores;
            let i = 0;

            while (i < this.qtd) {
                if (funcao(ptAux, nome)) {
                    return ptAux;
                }
                ptAux = ptAux.proxJogador;
                i++;
            }
            return false;
        }
    }

    InserirJogador(jog) { //Método para fazer a inserção de novos jogadores
        if (this.Vazio()) {
            this.ptJogadores = jog;
            //console.log(this.ptJogadores);
            this.qtd++;
            this.nomeJogadores.push(jog);
            return true;
        }
        else {
            let ptAux = this.ptJogadores;
            /*console.log(this.ptJogadores);
            console.log(ptAux);
            console.log(this.qtd);*/
            let i = 1;
            while (ptAux.proxJogador != null) {
                ptAux = ptAux.proxJogador;
            }
            if (this.qtd < 9) {
                ptAux.proxJogador = jog;
                this.qtd++;
                this.nomeJogadores.push(jog);
                return true;
            }
            if (this.qtd == 9) {
                ptAux.proxJogador = this.ptJogadores;
                this.nomeJogadores.push(jog);
                return true;
            }
        }
        return false;  
    }
/* Carta 2- Pula o próximo jogador e passa a vez para o seguinte;
   Carta 3 - Elimina o jogador atual;
   Carta 5 - Elimina o terceiro jogador contado a partir do jogador atual;
   Carta 7 - Elimina o jogador da rodada anterior (o jogador que tirou a carta antes); */

    carta2(ptAtual) {
        let anterior;
        let futuroAtual;

        futuroAtual = ptAtual.proxJogador.proxJogador;
        anterior = ptAtual.proxJogador;
        return {fa: futuroAtual, ant: anterior, carta: 2};
    }

    carta3(ptAnterior, ptAtual) {
        ptAnterior.proxJogador = ptAtual.proxJogador;
        if (ptAnterior.nome == this.ptJogadores.nome) {
            this.ptJogadores = ptAtual.proxJogador;
        }
        this.qtd--;
        return{fa: ptAtual.proxJogador, ant: ptAnterior, carta: 3};
    }

    carta5(ptAtual) {
        let prox;
        let anterior;
        let anterior2;
        let remove;

        prox = ptAtual.proxJogador;
        anterior = ptAtual;

        anterior2 = prox;
        remove = atras2.proxJogador;
        if (remove.nome == this.ptJogadores.nome) {
            this.ptJogadores = remove.proxJogador;
        }

        anterior2.proxJogador = remove.proxJogador;
        this.qtd--;
        return {fa: prox, ant: anterior, carta: 5};
    }

    carta7(ptAnterior, ptAtual) {
        let anterior;
        let ptAux1 = ptAtual;

        while (ptAux1.proxJogador.nome != ptAtual.nome) {
            ptAux1 = ptAux1.proxJogador;
        }

        if (ptAnterior.nome == this.ptJogadores.nome) {
            this.ptJogadores = ptAtual;
        }
        anterior = ptAux1;
        anterior.proxJogador = ptAtual;
        this.qtd--;
        return {fa: ptAtual.proxJogador, ant: ptAtual, carta: 7};

    }
}