let JogCarta = new JogoEnc();

function ListarJogadores() { //Função para listar o nome dos 10 jogadores participantes
    document.write("<br>Jogadores: <br>");
    for (i = 0; i < 10; i++) {
        document.write(`${JogCarta.nomeJogadores[i].nome} <br>`);
    }
}

function CadastrarJogadores() { //Função para cadastrar o nome dos jogadores
    let nome = window.prompt("Digite o nome do jogador: ");
    let joga = new Jogadores(nome);
    let final = JogCarta.Busca(nome, (ptAux, nome) => {
        return ptAux.nome == nome ? true : false;
    });

    if (final instanceof Jogadores) {
        let afi = final;

        while (afi instanceof Jogadores) {
            window.alert("Jogador já existe!");
            let nome1 = prompt("Digite outro nome: ");
            afi = JogCarta.Busca(nome1, (ptAux, nome) => {
                return ptAux.nome == nome1 ? true : false;
            });
        }
        let joga = new Jogadores(nome);
        let pos = JogCarta.InserirJogador(joga);
    }
    else {
        let pos = JogCarta.InserirJogador(joga);
    }
}

function Principal() { 
    opcao();
    document.write("<br>Programa Finalizado! <br>");
}

function opcao() {
    document.write("Cartas Online");
    for (i = 0; i < 10; i++) {
        CadastrarJogadores();
    }
    ListarJogadores();
}
document.addEventListener("DOMContentLoaded", () => Principal(), false);